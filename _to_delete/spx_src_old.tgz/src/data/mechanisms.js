// Textos didáticos de cada tipo de fragmentação (fáceis de editar)
export const MECHANISMS = {
  alpha: {
    short: 'α-clivagem',
    group: 'alpha',
    color: '#2563eb',
    text: 'O elétron desemparelhado do heteroátomo (sítio da ionização) forma uma nova ligação π com o carbono α; a ligação Cα–Cβ se rompe e o grupo vizinho sai como radical. O íon formado (imínio, oxônio, sulfônio) é estabilizado por ressonância — por isso é tão intenso.'
  },
  h_alpha: {
    short: 'α-clivagem (perda de H•)',
    group: 'alpha',
    color: '#2563eb',
    text: 'Mesma lógica da α-clivagem, mas a ligação rompida é Cα–H. Perder H• é menos favorável que perder um radical alquila, então o pico M − 1 costuma ser pequeno (exceto em aldeídos, aminas e alguns éteres).'
  },
  alpha_co: {
    short: 'α-clivagem da carbonila',
    group: 'alpha',
    color: '#7c3aed',
    text: 'A ionização remove um elétron n do O da carbonila. A ligação entre o C=O e um grupo vizinho se rompe; forma-se o íon acílio R–C≡O⁺, estabilizado por ressonância. Perde-se preferencialmente o radical maior/mais estável.'
  },
  inductive: {
    short: 'Clivagem indutiva (i)',
    group: 'inductive',
    color: '#16a34a',
    text: 'O heteroátomo eletronegativo atrai o par de elétrons da ligação C–Y; ele sai como radical •Y e a carga fica no carbono. Favorecida quando o carbocátion formado é estável (terciário, benzílico) e quando Y é Br ou I.'
  },
  hetero: {
    short: 'Carga no heteroátomo',
    group: 'inductive',
    color: '#16a34a',
    text: 'A ligação se rompe com a carga permanecendo no heteroátomo (ex.: I⁺, Br⁺, ArO⁺). Pela regra de Stevenson, a carga fica no fragmento de menor energia de ionização.'
  },
  benzylic: {
    short: 'Clivagem benzílica',
    group: 'sigma',
    color: '#ea580c',
    text: 'Rompe-se a ligação β ao anel aromático. O cátion benzílico é estabilizado por ressonância e, no caso de C₇H₇⁺ (m/z 91), rearranja-se ao íon tropílio, aromático (6 elétrons π em anel de 7 membros).'
  },
  allylic: {
    short: 'Clivagem alílica',
    group: 'sigma',
    color: '#d97706',
    text: 'Rompe-se a ligação vizinha à C=C (posição alílica). O cátion alílico é estabilizado por ressonância.'
  },
  aryl: {
    short: 'Perda do substituinte do anel',
    group: 'sigma',
    color: '#ea580c',
    text: 'O substituinte ligado diretamente ao anel sai como radical e forma-se o cátion arila (ex.: C₆H₅⁺, m/z 77). A ligação C(sp²)–X é forte, então esse caminho compete com a sobrevivência de M⁺•.'
  },
  sigma: {
    short: 'Clivagem σ (C–C)',
    group: 'sigma',
    color: '#64748b',
    text: 'Quebra de uma ligação C–C sem participação de heteroátomo. A carga fica com o fragmento que forma o carbocátion mais estável (terciário > secundário > primário > metila); em alcanos isso gera a série CₙH₂ₙ₊₁⁺ (m/z 29, 43, 57, 71…), espaçada de 14 u.'
  },
  h_loss: {
    short: 'Perda de H•',
    group: 'sigma',
    color: '#64748b',
    text: 'Perda de um átomo de hidrogênio (M − 1). Pouco favorável, exceto quando o cátion resultante é muito estabilizado (benzílico/tropílio, acílio).'
  },
  mclafferty: {
    short: 'Rearranjo de McLafferty',
    group: 'rearr',
    color: '#db2777',
    text: 'Um H do carbono γ é transferido ao átomo Y da ligação dupla (O da C=O, C do anel ou do alceno) por um estado de transição de 6 membros; a ligação Cα–Cβ se rompe e sai um alceno neutro. O íon é um cátion-radical: sem N, aparece em m/z par.'
  },
  water: {
    short: 'Perda de água (M − 18)',
    group: 'rearr',
    color: '#0891b2',
    text: 'Álcoois perdem H₂O com facilidade: o H vem preferencialmente do carbono 4 (eliminação 1,4, estado de transição cíclico). O íon M − 18 é um cátion-radical e pode ser confundido com M⁺• de um alceno.'
  },
  hx: {
    short: 'Perda de HX',
    group: 'rearr',
    color: '#0891b2',
    text: 'Haletos de alquila (sobretudo cloretos e fluoretos) eliminam HX, formando o cátion-radical de um alceno.'
  },
  rda: {
    short: 'Retro-Diels–Alder',
    group: 'rearr',
    color: '#c026d3',
    text: 'O cátion-radical de um ciclo-hexeno se divide no inverso da reação de Diels–Alder: formam-se um dieno e um alceno; a carga fica, em geral, no dieno.'
  },
  ring_c2h4: {
    short: 'Perda de eteno do anel',
    group: 'rearr',
    color: '#c026d3',
    text: 'Cicloalcanos abrem o anel (o que não muda a massa) e em seguida eliminam eteno (M − 28).'
  },
  phenol_co: {
    short: 'Perda de CO (fenol)',
    group: 'rearr',
    color: '#c026d3',
    text: 'Fenóis rearranjam-se (tautômero ceto) e eliminam CO: M − 28.'
  },
  phenol_cho: {
    short: 'Perda de CHO• (fenol)',
    group: 'rearr',
    color: '#c026d3',
    text: 'Fenóis também perdem HCO•, dando M − 29 (C₅H₅⁺, m/z 65 no fenol).'
  },
  ch2o: {
    short: 'Perda de CH₂O (anisol)',
    group: 'rearr',
    color: '#c026d3',
    text: 'Éteres aril-metílicos transferem um H da metila ao anel e eliminam formaldeído (M − 30).'
  },
  nitro_no: {
    short: 'Perda de NO• (nitro)',
    group: 'rearr',
    color: '#c026d3',
    text: 'O grupo nitro aromático se rearranja a nitrito (Ar–O–N=O) e perde NO• (M − 30); também é comum perder NO₂• (M − 46).'
  },
  ketene: {
    short: 'Perda de ceteno (M − 42)',
    group: 'rearr',
    color: '#c026d3',
    text: 'Acetanilidas e acetatos de arila transferem um H da metila ao N (ou O) e eliminam ceteno, CH₂=C=O. Forma-se o cátion-radical da anilina (ou do fenol) correspondente.'
  },
  hcn: {
    short: 'Perda de HCN (M − 27)',
    group: 'rearr',
    color: '#c026d3',
    text: 'Piridinas, anilinas e benzonitrilas expulsam HCN depois de abrir/rearranjar o anel: M − 27. Típico de compostos aromáticos nitrogenados.'
  },
  sec_co: {
    short: 'Secundária: perda de CO',
    group: 'secondary',
    color: '#94a3b8',
    text: 'O íon acílio perde CO (28 u) e forma o carbocátion R⁺. Importante quando R⁺ é estável (C₆H₅CO⁺ 105 → C₆H₅⁺ 77).'
  },
  sec_alkene: {
    short: 'Secundária: perda de alceno',
    group: 'secondary',
    color: '#94a3b8',
    text: 'Íons imínio/oxônio com um grupo N- ou O-alquila (≥ C₂) eliminam um alceno com transferência de H ao heteroátomo (ex.: 58 → 30 nas aminas, 59 → 31 nos éteres).'
  },
  sec_c2h2: {
    short: 'Secundária: perda de C₂H₂',
    group: 'secondary',
    color: '#94a3b8',
    text: 'Íons aromáticos perdem acetileno (26 u): 91 → 65, 77 → 51, 65 → 39.'
  },
  sec_h2: {
    short: 'Secundária: perda de H₂',
    group: 'secondary',
    color: '#94a3b8',
    text: 'Carbocátions alquila perdem H₂ e formam cátions alila/vinila: por isso cada grupo CₙH₂ₙ₊₁⁺ vem acompanhado de CₙH₂ₙ₋₁⁺ (43/41, 29/27…).'
  },
  sec_c2h4: {
    short: 'Secundária: perda de C₂H₄',
    group: 'secondary',
    color: '#94a3b8',
    text: 'Após perder água, o cátion-radical de álcoois primários elimina eteno (M − 18 − 28).'
  }
}

export const MECH_GROUPS = [
  { id: 'alpha', label: 'α-clivagens', desc: 'iniciadas pelo radical do heteroátomo ou da carbonila' },
  { id: 'inductive', label: 'Clivagens indutivas', desc: 'a carga migra para o carbono (ou fica no heteroátomo)' },
  { id: 'sigma', label: 'Clivagens σ, benzílicas e alílicas', desc: 'carbocátions estabilizados' },
  { id: 'rearr', label: 'Rearranjos', desc: 'transferência de H ou quebra de duas ligações — íons de m/z par (sem N)' },
  { id: 'secondary', label: 'Fragmentações secundárias', desc: 'íons que se fragmentam de novo' }
]

// Perdas neutras comuns a partir de M (tabela de consulta)
export const COMMON_LOSSES = [
  { d: 1, what: 'H•', hint: 'aldeídos, aminas, benzílicos' },
  { d: 15, what: '•CH₃', hint: 'grupo metila (ramificação, metil-cetona)' },
  { d: 16, what: '•NH₂ ou O', hint: 'amidas; N-óxidos, nitro' },
  { d: 17, what: '•OH ou NH₃', hint: 'ácidos carboxílicos; aminas' },
  { d: 18, what: 'H₂O', hint: 'álcoois (às vezes ácidos, aldeídos)' },
  { d: 19, what: 'F•', hint: 'fluoretos' },
  { d: 20, what: 'HF', hint: 'fluoretos' },
  { d: 26, what: 'C₂H₂ ou •CN', hint: 'aromáticos; nitrilas' },
  { d: 27, what: 'HCN', hint: 'nitrilas, heteroaromáticos nitrogenados' },
  { d: 28, what: 'CO ou C₂H₄', hint: 'fenóis, quinonas; McLafferty, cicloalcanos' },
  { d: 29, what: '•CHO ou •C₂H₅', hint: 'aldeídos, fenóis; grupo etila' },
  { d: 30, what: 'CH₂O ou NO', hint: 'éteres metílicos aromáticos; nitroaromáticos' },
  { d: 31, what: '•OCH₃ ou •CH₂OH', hint: 'ésteres metílicos; álcoois primários' },
  { d: 32, what: 'CH₃OH', hint: 'ésteres metílicos' },
  { d: 35, what: 'Cl•', hint: 'cloretos (verifique 37 também)' },
  { d: 36, what: 'HCl', hint: 'cloretos' },
  { d: 42, what: 'CH₂=C=O ou C₃H₆', hint: 'acetatos, acetamidas; McLafferty' },
  { d: 43, what: '•C₃H₇ ou CH₃CO•', hint: 'grupo propila; metil-cetonas' },
  { d: 44, what: 'CO₂', hint: 'ácidos, ésteres, anidridos' },
  { d: 45, what: '•OC₂H₅ ou •COOH', hint: 'ésteres etílicos; ácidos' },
  { d: 46, what: '•NO₂ ou C₂H₅OH', hint: 'nitro; ésteres etílicos' },
  { d: 57, what: '•C₄H₉', hint: 'grupo butila' },
  { d: 59, what: '•COOCH₃', hint: 'ésteres metílicos' },
  { d: 77, what: 'C₆H₅•', hint: 'derivados fenílicos' },
  { d: 79, what: 'Br•', hint: 'brometos (com 81)' },
  { d: 91, what: 'C₇H₇•', hint: 'derivados benzílicos' },
  { d: 127, what: 'I•', hint: 'iodetos' }
]

// Íons diagnósticos comuns de baixa massa
export const COMMON_IONS = [
  { mz: 29, what: 'C₂H₅⁺ ou HCO⁺' },
  { mz: 30, what: 'CH₂=NH₂⁺ (aminas primárias)' },
  { mz: 31, what: 'CH₂=OH⁺ (álcoois primários, éteres)' },
  { mz: 39, what: 'C₃H₃⁺ (aromáticos)' },
  { mz: 41, what: 'C₃H₅⁺ (alila)' },
  { mz: 43, what: 'C₃H₇⁺ ou CH₃CO⁺' },
  { mz: 44, what: 'McLafferty de aldeídos; CO₂⁺•' },
  { mz: 45, what: 'COOH⁺; CH₃CH=OH⁺' },
  { mz: 57, what: 'C₄H₉⁺ ou C₂H₅CO⁺' },
  { mz: 58, what: 'McLafferty de metil-cetonas' },
  { mz: 59, what: 'McLafferty de amidas; COOCH₃⁺' },
  { mz: 60, what: 'McLafferty de ácidos' },
  { mz: 65, what: 'C₅H₅⁺ (de 91)' },
  { mz: 74, what: 'McLafferty de ésteres metílicos' },
  { mz: 77, what: 'C₆H₅⁺ (fenila)' },
  { mz: 91, what: 'C₇H₇⁺ (tropílio)' },
  { mz: 92, what: 'McLafferty de alquilbenzenos' },
  { mz: 105, what: 'C₆H₅CO⁺ (benzoíla)' }
]
