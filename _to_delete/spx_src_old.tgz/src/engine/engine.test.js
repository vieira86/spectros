import { beforeAll, describe, expect, it } from 'vitest'
import init from '@rdkit/rdkit'
import { buildMolecule, analyzeMolecule, msReport } from './index.js'
import { isotopeRelative, nominalMass, monoMass, isobaricFormulas } from './mass.js'
import { EXAMPLES } from '../data/examples.js'

let R
beforeAll(async () => {
  R = await init()
})

function run(smiles) {
  const m = R.get_mol(smiles)
  const mol = buildMolecule(m.get_json(), m.get_molblock())
  m.delete()
  return analyzeMolecule(mol)
}
const rel = (an, mz) => an.peaks.find(p => p.mz === mz)?.rel ?? 0

describe('massas e isótopos', () => {
  it('massa nominal e exata', () => {
    expect(nominalMass({ C: 2, H: 6, O: 1 })).toBe(46)
    expect(monoMass({ C: 2, H: 6, O: 1 })).toBeCloseTo(46.0419, 3)
  })
  it('M+1 ≈ 1,1% por carbono', () => {
    const iso = isotopeRelative({ C: 10, H: 8 })
    expect(iso.find(x => x.d === 1).rel).toBeCloseTo(10.8, 0)
  })
  it('cloro 3:1 e bromo 1:1', () => {
    expect(isotopeRelative({ C: 6, H: 5, Cl: 1 }).find(x => x.d === 2).rel).toBeCloseTo(32.5, 0)
    expect(isotopeRelative({ C: 2, H: 5, Br: 1 }).find(x => x.d === 2).rel).toBeCloseTo(97.3, 0)
  })
  it('isóbaros de m/z 28', () => {
    const alt = isobaricFormulas({ C: 2, H: 4 }).map(x => x.text)
    expect(alt).toContain('CO')
  })
})

// pico-base e íons-chave esperados (espectros de referência de IE a 70 eV)
const CASES = [
  ['CCO', 31, [45, 46]],
  ['CCC(C)=O', 43, [72, 57]],
  ['CC(C)=O', 43, [58]],
  ['CCCCC(C)=O', 43, [58, 100]],
  ['Cc1ccccc1', 91, [92, 65]],
  ['CCc1ccccc1', 91, [106]],
  ['CCCc1ccccc1', 91, [92, 120]],
  ['CCNCC', 58, [30, 73]],
  ['CCCCN', 30, []],
  ['CCOCC', 59, [31, 74]],
  ['CCCCCC', 43, [57, 41, 29, 86]],
  ['CC(C)(C)C', 57, []],
  ['CCCCO', 31, [56]],
  ['CC(C)(C)O', 59, []],
  ['CCCC=O', 44, [72, 29]],
  ['CCCC(=O)O', 60, [73 - 2, 45]],
  ['CCCC(N)=O', 59, [44]],
  ['CCCC(=O)OC', 74, [71, 59]],
  ['CCOC(C)=O', 43, [88]],
  ['CC(=O)c1ccccc1', 105, [77, 120, 51]],
  ['O=Cc1ccccc1', 106, [105, 77]],
  ['Clc1ccccc1', 112, [114, 77]],
  ['CCCCCl', 56, [92, 94]],
  ['C1CCCCC1', 56, [84]],
  ['C1=CCCCC1', 54, [82]],
  ['CC1=CCC(CC1)C(C)=C', 68, [136]],
  ['Oc1ccccc1', 94, [66, 65]],
  ['COc1ccccc1', 108, [78]],
  ['O=[N+]([O-])c1ccccc1', 123, [77, 93]],
  ['c1ccncc1', 79, [52]],
  ['CC(=O)Nc1ccc(O)cc1', 109, [151, 43]]
]

describe('espectro simulado: pico-base e íons característicos', () => {
  for (const [smi, base, keys] of CASES) {
    it(smi, () => {
      const an = run(smi)
      expect(an.basePeak.mz).toBe(base)
      for (const k of keys) expect(rel(an, k)).toBeGreaterThan(2)
    })
  }
})

describe('regras clássicas', () => {
  it('regra do nitrogênio', () => {
    expect(run('CCCCN').nitrogen.odd).toBe(true)
    expect(run('CCCCO').nitrogen.odd).toBe(false)
  })
  it('bromoetano: par M/M+2 1:1', () => {
    const an = run('CCBr')
    expect(rel(an, 110) / rel(an, 108)).toBeCloseTo(0.97, 1)
  })
  it('McLafferty da 2-hexanona é cátion-radical de m/z par', () => {
    const p = run('CCCCC(C)=O').pathways.find(g => g.type === 'mclafferty')
    expect(p.mz).toBe(58)
    expect(p.oddElectron).toBe(true)
  })
  it('álcool terciário: M⁺• praticamente ausente', () => {
    expect(run('CC(C)(C)O').mInfo.rel).toBeLessThan(2)
  })
  it('texto no formato de artigo', () => {
    expect(msReport(run('CC(=O)c1ccccc1'))).toMatch(/^EM \(IE, 70 eV\), m\/z \(%\): 120 \(M⁺•, \d+\), 105 \(100\)/)
  })
  it('todos os exemplos rodam', () => {
    for (const ex of EXAMPLES) {
      const an = run(ex.smiles)
      expect(an.peaks.length).toBeGreaterThan(1)
      expect(an.basePeak.rel).toBeCloseTo(100, 5)
    }
  })
})
